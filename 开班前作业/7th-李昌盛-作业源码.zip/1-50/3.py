x = int(input("x:"))
print("x*x:"+str(x*x))