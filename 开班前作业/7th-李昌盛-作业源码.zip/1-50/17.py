a = int(input("a:"))
p=1
for i in range(1,a+1):
    p=p*i
print("a!:"+str(p))