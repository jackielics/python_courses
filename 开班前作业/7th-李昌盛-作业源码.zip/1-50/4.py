x = int(input("x:"))
print("3x^2+5x+6:"+str(3*x*x+5*x+6))