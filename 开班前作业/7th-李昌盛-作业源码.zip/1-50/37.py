# Python 计算数组元素之和（list内的元素个数自定）

li = [i for i in range(10)]
sum = sum(li)
print(sum)