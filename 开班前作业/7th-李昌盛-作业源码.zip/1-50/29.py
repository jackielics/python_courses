s1 = input("Str1:")
s2 = input("Str2:")
if(s1 == s2):
    print("Equal!")
else:
    print("Not Equal!")