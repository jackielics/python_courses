# Python 查找列表中最大元素（list内的元素自定）
li = [i for i in range(10)]
max = max(li)

print(max)