# Python 计算列表元素之和（list内的元素自定）
li = [i for i in range(10)]
sum = sum(li)
print(sum)