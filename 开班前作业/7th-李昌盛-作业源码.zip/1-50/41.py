# Python 翻转列表，相当于将列表逆序（list内的元素自定）
li = [i for i in range(20)]
li.reverse()
print(li)