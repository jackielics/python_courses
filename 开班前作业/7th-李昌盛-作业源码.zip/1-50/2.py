x1 = int(input("x1:"))
x2 = int(input("x2:"))
print("x1+x2:"+str(x1+x2))