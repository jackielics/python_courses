# Python 查找列表中最小元素（list内的元素自定）
li = [i for i in range(10)]
min = min(li)

print(min)