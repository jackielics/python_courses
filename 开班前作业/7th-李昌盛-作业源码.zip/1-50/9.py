a = int(input("a:"))
b = int(input("b:"))
t = a
a = b
b = t
print("a:"+str(a))
print("b:"+str(b))
