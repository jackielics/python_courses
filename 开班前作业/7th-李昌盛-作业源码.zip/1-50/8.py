for i in range(4,0,-1):
    for _ in range(i):
        print("*",end="")
    print("")

# https://blog.csdn.net/DisolveDislove/article/details/120379687