# Python 复制列表a中元素到列表b中（list内的元素自定）
la = [i for i in range(20)]
lb = la.copy()
print(lb)
