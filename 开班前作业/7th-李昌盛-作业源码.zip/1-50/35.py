import time,datetime

while(True):
    time.sleep(1)
    print(str(datetime.datetime.now()))