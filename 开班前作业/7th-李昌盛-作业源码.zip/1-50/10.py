a = int(input("a:"))
if(a>0 and a<10):
    print("正确")
else:
    print("错误")