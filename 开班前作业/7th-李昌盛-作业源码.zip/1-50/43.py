# Python 清空列表（list内的元素自定）
li = [i for i in range(20)]
li = []
print(li)