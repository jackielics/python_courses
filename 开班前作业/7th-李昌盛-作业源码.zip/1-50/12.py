a = int(input("a:"))
if a%2==0:
    print("偶数")
else:
    print("奇数")