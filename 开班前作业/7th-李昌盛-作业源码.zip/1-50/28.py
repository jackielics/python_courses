with open("D:\Codes\pywd\感想",'r',encoding='utf8') as f:
    print(f.read())