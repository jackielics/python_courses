import random
for i in range(10):
    print(random.uniform(0,100))
# https://www.jb51.net/article/226993.htm