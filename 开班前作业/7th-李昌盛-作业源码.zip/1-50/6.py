import math
r = int(input("r:"))
s = math.pi*r*r
print(s)