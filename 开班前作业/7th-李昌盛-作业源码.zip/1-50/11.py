a = input("a:")
if a.isdigit():
    print("正确")
else:
    print("错误")
    
# https://blog.csdn.net/sinat_41890480/article/details/114267625