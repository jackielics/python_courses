# import datetime
# today = datetime.datetime.now()
# year = today.year
# month = today.month
# print(month(year,month))


while True:
    speech_in = input("INput:")
    print(input)

# score = int(input('请输入一个数字:'))
# grade = 'abcde'
# mun = 0
# if score>100  or score<0:
#     print('数字不符合条件!请重新输入')
# else:
#     num = score//10
#     if num<6:
#         num=5
#     print("分数是{0},等级是{1}".format(score,grade(9-num)))