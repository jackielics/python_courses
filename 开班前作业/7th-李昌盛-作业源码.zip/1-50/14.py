a = int(input("a:"))
b = int(input("b:"))
if a>=b:
    print(a)
else:
    print(b)