def recursion(i:int,j:int,now:int,max:int)->int:
    # return i+j
    # if(now>=max):# 退出条件
    #     return now
    


