# Python 将字符串作为代码执行（字符串内容自定）

s = "a = 10000"

exec(s)

print(a)