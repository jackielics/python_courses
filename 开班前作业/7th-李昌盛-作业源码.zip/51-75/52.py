# Python 判断字符串长度 （字符串内容读取输入获得）
s = input("STR:")
print(len(s))