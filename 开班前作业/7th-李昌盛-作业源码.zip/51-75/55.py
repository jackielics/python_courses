# Python 字符串翻转（字符串内容自定）
s = "a = 10000"
sl = list(s)
sl.reverse()
s2 = ''.join(sl)
print(s2)