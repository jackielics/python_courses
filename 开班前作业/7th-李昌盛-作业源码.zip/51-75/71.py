# 71. Python 归并排序（列表元素自定）

# def recursion(list ):
    